var nombre= prompt('¿Como se llama?');
var mensaje =('Bienvenido a la matrix '+nombre);
console.log(mensaje);