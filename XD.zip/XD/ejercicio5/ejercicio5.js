var todo = parseInt (prompt ('Deme un numero para sacarle el 15%'));
todo = todo-((todo*15)/100);
alert ('El descuento del 15% es '+todo)