//2,5,6,3,10,6,7
var nombre = [2,5,6,3,10,6,7];

for (var i=7; i<0; i--){
    console.log(nombre[i]);
}