//2,4,1,5,6,3
var array = [2,4,1,5,6,3];
for (var i=0;i<7;i++){
    suma=0;
    suma=parseInt(array[i]) + parseInt(array[i+1]);
    if (suma == 11){
        console.log (suma);
    }
}

