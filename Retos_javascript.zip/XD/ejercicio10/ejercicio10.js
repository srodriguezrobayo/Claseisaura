var usuarios =[
    {nombre:"Gino",puntaje:213},
    {nombre:"Nora",puntaje:337},
    {nombre:"Emily",puntaje:425},
    {nombre:"Jack",puntaje:0},
    {nombre:"Alejandro",puntaje:103},
    {nombre:"Enrique",puntaje:32}
];
for (var i = 0; i < 6 ; i++){
    console.log (usuarios[i]);
    console.log('________');
}