var num1 = parseInt (prompt ('Deme el primer numero'));
var num2 = parseInt (prompt('Deme el segundo numero'));
var sum = num1+num2;
alert ('El resultado de la suma es '+sum);
var num3 = parseInt (prompt ('deme un tercer numero'));
var mul = sum*num3;
alert ('El resultado de la multiplicacion es '+mul);