var kilometro = parseFloat(prompt ('Cuantos kilometros va a recorrer'));
var gasolina = parseFloat (prompt ('cuantos litros va tanquea de gasolina'));
var gasto = kilometro / gasolina;
console.log ('Usted por kilometro gasta '+gasto+ 'litros de gasolina')
