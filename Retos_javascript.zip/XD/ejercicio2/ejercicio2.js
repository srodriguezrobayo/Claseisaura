var num1 = prompt ('Deme el primer numero decimal');
var num2 = prompt ('Deme el segundo numero entero');
var sum = parseFloat(num1) + parseInt(num2);
console.log ('El resultado de la suma es: '+sum);